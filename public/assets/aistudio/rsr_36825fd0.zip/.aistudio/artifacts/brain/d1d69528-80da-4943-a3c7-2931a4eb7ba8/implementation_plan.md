# RSR Dual-Bus Volume Control, Gyroscope Tilt & Interactive Guide

Implement a single-track dual-thumb volume controller (independent Music vs. Interactive SFX volumes), phone gyroscope perspective canvas tilt, and a top-left sleek glass button with a Gaming icon that triggers a guide popup detailing all desktop and mobile cosmic mechanics—strictly preserving the "RSR" branding and pure black with sharp cyan aesthetic.

## User Review & Critical Decisions

> [!IMPORTANT]
> The site branding remains strictly **"RSR"**, the description is strictly **"The Main Community Hub"**, and the visual palette is pure black (`#000000`) with sharp cyan (`#00f2fe`) accents. All existing card positions and scroll-depth reveals remain preserved.

- **Confirmed Decision 1 (Dual-Thumb Single-Track Volume Controller)**:
  - On the left of the slider: a solid white "Music" icon (`fa-music text-white`).
  - Track hosts two independent draggable dots:
    - **Dot A (Interactive SFX)**: Pure black dot with a black border controlling the synthesized cosmic sound effects (chimes, whoosh, rumble, pings). Paired with a volume icon that is pure black with a slim white border.
    - **Dot B (Music Volume)**: Completely white dot controlling the background music track.
  - Custom HTML/Canvas/SVG or dual range slider with precision drag and touch tracking.

- **Confirmed Decision 2 (Phone Gyroscope Perspective Canvas Tilt)**:
  - Listen for `deviceorientation` event (`gamma` roll and `beta` pitch).
  - Translates phone incline into smooth perspective tilt and parallax center shifting on the vortex canvas.
  - Spring dampening to keep motion physical, silky, and jitter-free.

- **Confirmed Decision 3 (Top-Left Sleek Gaming Button & Mechanics Guide)**:
  - Positioned at fixed top-left (`top-6 left-6`), matching the sleek glass style of the top-right social icons.
  - Features a Gaming controller icon on its left and a subtle Gyro sensor activation trigger.
  - Clicking/tapping opens a glassmorphism modal popup showcasing the interactive features for both Desktop (click chimes, fast-swipe comet redirection, hold-spawn, scroll-pinch) and Mobile (tap, swipe deflection, hold-birth, two-finger pinch event horizon scaling, gyroscope tilt).

---

## 1. Overview & Core Concept

- **What It Delivers**:
  1. **Precision Dual Sound Balance**: Gives users independent mastery over background music versus synthesized celestial interaction sounds without leaving the main viewport dock.
  2. **Tactile Gyroscopic Reality**: Physical orientation of mobile devices directly leans and tilts the ambient vortex perspective in real time.
  3. **Discoverable Interaction Mechanics**: A sleek in-universe guide letting visitors easily discover hidden gestures (two-finger pinch, hold-to-birth, swipe deflections, and tilt).

---

## 2. User Experience & Visual Design

### Dual-Dot Volume Slider
- **Track & Thumbs**:
  - A slim 3px horizontal track with dual independent handles:
    - **Music Handle**: Solid white circular dot with glow highlight.
    - **SFX Handle**: Pure black circular dot with a slim black/white outline for crisp contrast on the track.
  - Left indicator: Completely white music note icon.
  - Right indicator: Pure black volume speaker icon with a razor-thin white border.

### Gyroscope Perspective Tilt
- **Smooth Inertia**: Tilting a smartphone left/right (`gamma` ±35°) and forward/backward (`beta` ±30°) drives the canvas focal parallax and orbital tilt smoothly using dampening filters.
- **Permission Flow**: For iOS Safari, the top-left button seamlessly requests device orientation permission via `DeviceOrientationEvent.requestPermission()`.

### Top-Left Gaming Guide Button & Popup
- **Button Styling**: Sleek glassmorphism panel matching the top-right Discord and Telegram buttons:
  - Deep black translucent glass (`rgba(15, 15, 18, 0.65)`), border (`rgba(255, 255, 255, 0.08)`), hover border glow.
  - Gaming controller icon on the left, subtle "Guide / Gyro" label.
- **Modal Mechanics Guide**:
  - Dark glassmorphism modal with backdrop blur.
  - Structured tabs or columns contrasting **Desktop Controls** (Mouse, Swipes, Modifier-Wheel) vs. **Mobile Gestures** (Taps, Flicks, Long-Press, Two-Finger Pinch, Gyro Tilt).
  - Close button and click-outside dismissal.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual-Thumb Drag Handling**
  - *Chosen Approach*: Pointer-event coordinate tracking mapped to percentage positions along the shared track, with distinct active hit-targets for both the white Music thumb and black SFX thumb.
  - *Why*: Allows two distinct volume buses (Music vs. Sound FX) to coexist in a minimal 140px dock footprint without cluttering the player bar.

- **Decision 2: Gyroscope Calibration**
  - *Chosen Approach*: Relative delta from resting position (calibrated on initial orientation) with soft clamp limits (±30px parallax offset).
  - *Why*: Prevents erratic jumps if the user holds their phone in bed, tilted, or standing.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────┐
│                          RSR                           │
│                                                        │
│  [Top Bar UI]                                          │
│  ├── Top-Left: Sleek Gaming Button ──> Mechanics Guide │
│  │             └── Gyro Permission Trigger             │
│  └── Top-Right: Discord & Telegram Social Buttons      │
│                                                        │
│  [Dual Volume System]                                  │
│  ├── Music Bus (audioRef.volume) <── White Dot         │
│  └── SFX Bus (Web Audio Gain)    <── Black Dot         │
│                                                        │
│  [Canvas Physics Engine]                               │
│  ├── Pointer Parallax + Gyroscope Beta/Gamma Tilt      │
│  ├── Orbiting Comets (Swipe Deflection & Hold-Spawn)   │
│  └── Violent Black Hole (Two-Finger Pinch Scalable)    │
└────────────────────────────────────────────────────────┘
```

### Component & State Mapping
- `musicVolume` (0.0 to 1.0, default 0.1): Controls `<audio>` playback volume.
- `sfxVolume` (0.0 to 1.0, default 0.15): Controls Web Audio synthesized effects gain.
- `gyroState`: Tracks `tiltX`, `tiltY`, and sensor availability.
- `isGuideOpen`: Controls display of the interactive mechanics popup.
