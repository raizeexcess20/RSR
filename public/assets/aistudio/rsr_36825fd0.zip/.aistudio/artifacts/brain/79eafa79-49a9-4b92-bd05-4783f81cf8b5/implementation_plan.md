# RSR Community Hub - Ingestion & Vibe Coding Roadmap

Your complete codebase has been successfully received, mapped, and structured in the workspace. This plan outlines immediate build verification and sets the stage for rapid, interactive vibe coding.

## User Review & Critical Decisions

> [!IMPORTANT]
> The full project files (`index.html`, `metadata.json`, `package.json`, `server.js`, `src/App.tsx`, and `src/index.css`) are already loaded in place. All core interactive mechanics—including the Cyan Vortex physics engine, Web Audio celestial synthesis, dual-track volume controller, and mobile gyroscope 3D tilt—are preserved.

- **Confirmed Identity**: App Name is **"RSR"**, Tagline: **"The Main Community Hub"**, Theme Color: **`#00f2fe`** (Cyan on Pure Black `#000000`).
- **Architecture**: Single Page Application powered by React 19 + Tailwind CSS + Vite, with an Express static production server fallback (`server.js`).
- **Immediate Step**: Run compilation and linting verification upon your approval to ensure the live preview dev server renders cleanly with zero errors.

---

## 1. Overview & Core Concept

- **What It Does**: A dark-mode, cosmic community hub featuring an interactive procedural Cyan Vortex with orbiting comets, a violent central black hole, procedural Web Audio effects, dual sound volume management, and community links for Discord ("Agartha") and Telegram ("RSR").
- **Target Audience**: Community members, visitors, and gamers experiencing cosmic ambient visuals and real-time community engagement.
- **Key Value**: Distinctive aesthetic, rich physics micro-interactions, responsive mobile gyroscope tilt, and seamless audio controls.

---

## 2. User Experience & Interactive Systems

```
┌────────────────────────────────────────────────────────┐
│                        VIEWPORT                        │
│                                                        │
│  [Top Bar]                                             │
│  ├── Top-Left: Mechanics Guide Button (Gamepad Icon)   │
│  │             └── Opens Modal & Triggers Gyro Sensor  │
│  └── Top-Right: Discord & Telegram Quick Links         │
│                                                        │
│  [Dynamic Canvas Layer]                                │
│  ├── Orbiting Comets (Swipe Deflection & Hold-Spawn)   │
│  ├── Central Black Hole (Tidal Shredding & Pinch Zoom) │
│  └── 3D Parallax Tilt (Pointer Move + Phone Gyroscope) │
│                                                        │
│  [Centered Community Showcase] (Revealed on Scroll)    │
│  ├── Discord Card (Live Agartha Member Count & Avatar) │
│  └── Telegram Card (RSR Compact Counter)               │
│                                                        │
│  [Fixed Bottom Audio Dock]                             │
│  ├── Spinning Vinyl Disc + Play/Pause Control          │
│  └── Dual Volume Slider:                               │
│      ├── Black Dot ──> Procedural Web Audio SFX        │
│      └── White Dot ──> Ambient Background Music        │
└────────────────────────────────────────────────────────┘
```

### Core Interactions:
1. **Interactive Cyan Vortex**:
   - **Click / Tap**: Procedural pentatonic chime, expanding shockwave ripple, micro-sparks, and rotational impulse.
   - **Fast Swipe**: Aerodynamic spatial whoosh SFX with real-time comet trajectory and velocity deflection.
   - **Hold Click / Long Press**: Celestial ping with birth auras, spawning new comets into orbit.
   - **Two-Finger Pinch / Ctrl+Wheel**: Compresses or expands the event horizon and tidal disruption radius.
   - **Phone Gyroscope**: Real-time perspective warp and parallax shifting according to device tilt (`gamma` roll and `beta` pitch).
2. **Dual-Thumb Volume Control**:
   - Single 3px groove track hosting independent draggable thumbs:
     - **Black Dot**: Controls interactive synthesized SFX gain.
     - **White Dot**: Controls `<audio>` background music volume.
3. **Community Hub Cards**:
   - Dynamic Discord API fetch for live member presence and server avatar.
   - Telegram community direct invite.

---

## 3. Key Product Decisions & Status

- **Codebase Integrity**:
  - *Status*: The entire codebase is present in `/src/App.tsx`, `/src/index.css`, `/index.html`, and `/server.js`. No placeholder code exists.
- **Verification First**:
  - *Next Action*: Execute a compilation check (`compile_applet` and `lint_applet`) to ensure TypeScript types and CSS builds pass cleanly on the dev server.
- **Ready for Vibe Coding**:
  - Once verified, you can immediately prompt any visual refinements, new community sections, animations, audio tracks, or extra features.

---

## 4. Technical Architecture & File Map

```
Workspace Structure
├── index.html                   # HTML shell with OpenGraph, Font Awesome & SEO
├── metadata.json                # "RSR" name & "The Main Community Hub" metadata
├── package.json                 # React 19, Tailwind CSS, Express, tsx
├── server.js                    # Express static file server for production
├── public/                      # Static assets & HTML backups
└── src/
    ├── main.tsx                 # React DOM root entry
    ├── index.css                # Global styles, canvas rules, custom sliders
    └── App.tsx                  # Complete application logic & canvas engine
```

### Next Step:
Click **Proceed** below to trigger compilation verification and confirm the live dev server is healthy and running.
